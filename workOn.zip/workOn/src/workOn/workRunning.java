package workOn;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;
import java.util.Random;

public class workRunning {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Robot wr=new Robot();
		Random rd= new Random();
		while(true){
			wr.delay(1000*60);
			Point p=MouseInfo.getPointerInfo().getLocation();
			System.out.println(p.x+","+p.y);
			wr.mouseMove(p.x+(rd.nextInt()%640), p.y+(rd.nextInt()%480));
			wr.mouseMove(p.x-(rd.nextInt()%640), p.y-(rd.nextInt()%480));
			p=MouseInfo.getPointerInfo().getLocation();
			System.out.println(p.x+","+p.y);
		}
	}

}

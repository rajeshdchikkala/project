/**
 * 
 */
package com.fedex.safetnetportal.auth.repository;

/**
 * @author 3820427
 *
 */
public class UserRepository {

}
